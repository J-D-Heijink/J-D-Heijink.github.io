public class Main {
  public static void main(String[] args) {

    Employee jack = new Employee("Jack");

    System.out.println(jack.calculateSalary());

    jack.setSalaryStrategy(new RegularSalaryStrategy());

    System.out.println(jack.calculateSalary());

    jack.setSalaryStrategy(emp -> 2500);
    System.out.println(jack.calculateSalary());

  }
}