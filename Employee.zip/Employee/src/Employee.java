public class Employee {

  private SalaryStrategy salaryStrategy;

  public String getName() {
    return name;
  }

  public int getHoursWorked() {
    return hoursWorked;
  }

  public int getHoursOvertime() {
    return hoursOvertime;
  }

  private String name;

  private int hoursWorked;

  private int hoursOvertime;

  public Employee(String name) {
    this.name = name;
    hoursWorked = hoursOvertime = 0;
    salaryStrategy = (emp) -> {
      System.out.println("calc salary for temp emp");
      return emp.getHoursWorked() * 13;
    };
  }

  public int calculateSalary() {
    return salaryStrategy.calculateSalary(this);
  }

  public void setSalaryStrategy(SalaryStrategy strategy) {
    this.salaryStrategy = strategy;
  }
}
