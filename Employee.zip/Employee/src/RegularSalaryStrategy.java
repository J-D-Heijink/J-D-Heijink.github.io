public class RegularSalaryStrategy implements SalaryStrategy {
  @Override
  public int calculateSalary(Employee employee) {
    System.out.println("calc salary for regular emp");
    return 1500 + employee.getHoursOvertime() * 25;
  }

}
