public interface SalaryStrategy {
  int calculateSalary(Employee employee);
}
