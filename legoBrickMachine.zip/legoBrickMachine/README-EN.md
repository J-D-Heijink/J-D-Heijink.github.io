# Brickmachine - Observer
## Difficulty: ![Filled](resources/star-filled.svg) ![Outlined](resources/star-filled.svg) ![Outlined](resources/star-outlined.svg) 

The brickmachine application produces batches of bricks. The batches are stored inside the BrickMachine 
(it is out of the scope of this exercise to find a better solution for this storage location).

All of the logic and behaviour to produce bricks is done inside the legoMachine package. There is however another package named: 'Dashboard'.

The challenge in this exercise is to update the dashboard with the right information based on the actions of the legoMachine, without
creating dependencies between the legoMachine and the Dashboard. You should use the observer pattern to do this.

Some information about the stats in the dashboard:


| Stat | Description  |
| ------- | --- |
| smallBatchesCreated | batches with 0-10 bricks (after removing the failed bricks) |
| mediumBatchesCreated | batches with 11-50 bricks (after removing the failed bricks) |
| bigBatchesCreated | batches with >=51 bricks (after removing the failed bricks) |
| failedBricksProduced | number failed produced bricks |

Tips:
- Create a publisher and subsriber
- Implement the publisher in your code, on which place in the legoMachine package does this need to be implemented?
- A tip can be found when you check the TODO's in this project!
- note: normally you prefer not to store data on 2 locations (we for example store the nr of small sets in the dashboard and indirectly in the BrickMachine). To refactor this to a better solution is out of the scope of this exercise. We prefer to focus on the Observer pattern in this exercise.

## Example
![](resources/dashboard.png)

## Relevant links
* [Java documentation of the SaxionApp](https://saxionapp.hboictlab.nl/nl/saxion/app/SaxionApp.html)
* [info about observer pattern](https://refactoring.guru/design-patterns/observer)
