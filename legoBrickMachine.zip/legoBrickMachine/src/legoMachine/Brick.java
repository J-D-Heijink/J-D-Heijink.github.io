package legoMachine;

import java.awt.*;

public class Brick {
    public enum BrickTypes {B1x1, B2x2, B3x2}

    private BrickTypes brickType;
    private Color color;

    public Brick(BrickTypes brickType, Color color) {
        this.brickType = brickType;
        this.color = color;
    }
}
