package legoMachine;

import nl.saxion.app.SaxionApp;
import observer.AbstractSubject;

import java.awt.*;
import java.util.ArrayList;

public class BrickMachine extends AbstractSubject {
    private static int LASTBATCH_ID = 0;

    ArrayList<Batch> batchesProduces = new ArrayList<>();


    public String produceBatch(Brick.BrickTypes type, int ammount, Color color){
        String batchName = "batch-"+(LASTBATCH_ID++);
        Batch batch = new Batch(batchName); //use id to make a new name for this batch
        for (int i = 0; i < ammount; i++) {

            int randomRoll = SaxionApp.getRandomValueBetween(0, 101);
            if(randomRoll < 10){
                notifyObservers("failedBrick");
            }


            Brick newBrick = new Brick(type, color);
            batch.addBrick(newBrick);
        }
        batchesProduces.add(batch);
        var aspect = ammount < 10 ? "addedSmallBatch" : ammount < 50 ? "addedMediumBatch": "addedBigBatch";
        notifyObservers(aspect);
        return batchName;
    }


}
