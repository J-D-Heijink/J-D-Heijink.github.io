package legoMachine;

import java.util.ArrayList;

public class Batch {
    private String batchName;
    private ArrayList<Brick> bricks = new ArrayList<>();

    private int failedBricks = 0;

    public int getFailedBricks() {
        return failedBricks;
    }

    public void setFailedBricks(int failedBricks) {
        this.failedBricks = failedBricks;
    }

    public Batch(String batchName) {
        this.batchName = batchName;
    }


    public int getNumberOfBricks(){
        return bricks.size();
    }

    public void addBrick(Brick brick){
        bricks.add(brick);
    }
}
