package observer;

public interface Observer {

  void processUpdate(Subject subject, String aspect);
}
