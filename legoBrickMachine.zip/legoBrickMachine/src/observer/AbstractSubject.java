package observer;

import java.util.HashSet;

public class AbstractSubject implements Subject {

  private HashSet<Observer> observers = new HashSet();

  public synchronized void addObserver(Observer observer) {
    if (observers.contains(observer)) {
      throw new IllegalArgumentException("cannot add observer if it is already observing");
    }
    observers.add(observer);
  }

  public synchronized void removeObserver(Observer observer) {
    if (!observers.remove(observer)) {
      throw new IllegalArgumentException("cannot remove observer if it is not observing");
    }
  }

  protected synchronized void notifyObservers(String aspect) {
    for (var observer: observers) {
      try {
        observer.processUpdate(this, aspect);
      } catch (Exception e) {
        System.err.printf("ignoring observer exception: %s\n", e.getMessage());
      }
    }
  }

}
