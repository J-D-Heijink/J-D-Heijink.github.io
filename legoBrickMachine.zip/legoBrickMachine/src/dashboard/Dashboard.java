package dashboard;

import legoMachine.BrickMachine;
import nl.saxion.app.SaxionApp;
import observer.Observer;
import observer.Subject;

public class Dashboard implements Observer {
    int smallBatchesCreated = 0;
    int mediumBatchesCreated = 0;
    int bigBatchesCreated = 0;

    int failedBricksProduced = 0;

    BrickMachine brickMachine;

    public Dashboard(BrickMachine brickMachine) {
        this.brickMachine = brickMachine;
        brickMachine.addObserver(this);
    }

    public void printOverview(){
        SaxionApp.printLine("============= DASHBOARD =============");
        SaxionApp.printLine("Sets produced:");
        SaxionApp.printLine("small: " + smallBatchesCreated);
        SaxionApp.printLine("medium: " + mediumBatchesCreated);
        SaxionApp.printLine("big: " + bigBatchesCreated);
        SaxionApp.printLine();
        SaxionApp.printLine("failed bricks: " + failedBricksProduced);
        SaxionApp.printLine("=====================================");
    }

    @Override
    public void processUpdate(Subject subject, String aspect) {
        switch (aspect) {
            case "failedBrick": ++failedBricksProduced; break;
            case "addedSmallBatch": ++smallBatchesCreated; break;
            case "addedMediumBatch": ++mediumBatchesCreated; break;
            case "addedBigBatch": ++bigBatchesCreated; break;
        }
    }
}
