import dashboard.Dashboard;
import legoMachine.Brick;
import legoMachine.BrickMachine;
import nl.saxion.app.SaxionApp;

import java.awt.*;

public class Application implements Runnable{
    public static void main(String[] args) {
        SaxionApp.start(new Application(), 700, 700);
    }

    BrickMachine brickMachine;
    Dashboard dashboard;

    @Override
    public void run() {
        brickMachine = new BrickMachine();
        dashboard = new Dashboard(brickMachine);
        boolean isRunning = true;

        while(isRunning){
            SaxionApp.printLine("Welcome to the brickmachine!");
            SaxionApp.printLine("What would you like to do?");
            SaxionApp.printLine("1. Create batch");
            SaxionApp.printLine("2. Show Dashboard");
            SaxionApp.printLine("3. Exit");

            SaxionApp.print("Your input: ");
            int userInput = SaxionApp.readInt();

            if(userInput == 1){
                createBatch();
            }else if(userInput == 2){
                dashboard.printOverview();
            }else if(userInput == 3){
                SaxionApp.printLine("bye bye");
                isRunning = false;
            }

            SaxionApp.pause();
            SaxionApp.clear();
        }

    }


    private void createBatch(){
        //ask type
        SaxionApp.printLine("Batch type:");
        SaxionApp.printLine("1. 1x1 bricks");
        SaxionApp.printLine("2. 2x2 bricks");
        SaxionApp.printLine("3. 3x2 bricks");
        int userInput = SaxionApp.readInt();
        while(userInput <1 || userInput > 3){
            SaxionApp.printLine("That is not a valid batch type");
            userInput = SaxionApp.readInt();
        }
        Brick.BrickTypes type = Brick.BrickTypes.B1x1;
        if(userInput == 2){
            type = Brick.BrickTypes.B2x2;
        }else{
            type = Brick.BrickTypes.B3x2;
        }

        //ask color
        SaxionApp.printLine("Color:");
        SaxionApp.printLine("1. red");
        SaxionApp.printLine("2. gray");
        SaxionApp.printLine("3. blue");
        SaxionApp.printLine("4. black");
        userInput = SaxionApp.readInt();
        while(userInput <1 || userInput > 4){
            SaxionApp.printLine("That is not a valid color");
            userInput = SaxionApp.readInt();
        }
        Color color = Color.red;
        if(userInput == 2){
            color = Color.gray;
        }else if(userInput == 3){
            color = Color.blue;
        }else if(userInput == 4){
            color = Color.black;
        }

        //ask ammount
        SaxionApp.print("How many?: ");
        int ammount = SaxionApp.readInt();

        //produce
        String name = brickMachine.produceBatch(type, ammount, color);
        SaxionApp.printLine("Batch " + name + " produced!");
    }
}
