package nl.saxion.concurrency.bank.actors;

import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;
import nl.saxion.concurrency.bank.domain.Account;
import nl.saxion.concurrency.bank.domain.BalanceException;
import nl.saxion.concurrency.bank.messages.BankMessage;

public class AccountManagerActor extends AbstractBehavior<BankMessage> {

    private final Account account;

    public AccountManagerActor(ActorContext<BankMessage> context, Account account) {
        super(context);
        this.account = account;
    }

    public static Behavior<BankMessage> create(Account account) {
        return Behaviors.setup(context -> new AccountManagerActor(context, account));
    }

    @Override
    public Receive<BankMessage> createReceive() {
        return newReceiveBuilder()
                .onMessage(BankMessage.WithDrawalMessage.class, this::withdraw)
                .onMessage(BankMessage.DepositMessage.class, this::deposit)
                .onMessage(BankMessage.BalanceMessage.class, this::getBalance)
                .build();
    }

    private Behavior<BankMessage> withdraw(BankMessage.WithDrawalMessage message) {
        try {
            long balance = account.take(message.amount);
            message.replyTo.tell(new BankMessage.GeneralReplyMessage(true, "Your new balance is " + balance));
        } catch (BalanceException e) {
            message.replyTo.tell(new BankMessage.GeneralReplyMessage(false, "Insufficient funds"));
        }
        return Behaviors.same();
    }

    private Behavior<BankMessage> deposit(BankMessage.DepositMessage message) {
        long balance = account.deposit(message.amount);
        message.replyTo.tell(new BankMessage.GeneralReplyMessage(true, "Your new balance is " + balance));
        return Behaviors.same();
    }

    private Behavior<BankMessage> getBalance(BankMessage.BalanceMessage message) {
        message.replyTo.tell(new BankMessage.GeneralReplyMessage(true, "Your balance is " + account.getBalance()));
        return Behaviors.same();
    }
}
