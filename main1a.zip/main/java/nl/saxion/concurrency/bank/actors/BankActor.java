package nl.saxion.concurrency.bank.actors;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.*;
import nl.saxion.concurrency.bank.domain.Account;
import nl.saxion.concurrency.bank.messages.BankMessage;

import java.util.HashMap;
import java.util.UUID;

public class BankActor extends AbstractBehavior<BankMessage> {

    private HashMap<String, ActorRef<BankMessage>> accounts = new HashMap<>();

    public BankActor(ActorContext<BankMessage> context) {
        super(context);
    }

    public static Behavior<BankMessage> create() {
        return Behaviors.setup(BankActor::new);
    }

    @Override
    public Receive<BankMessage> createReceive() {
        return newReceiveBuilder()
                .onMessage(BankMessage.CreateAccountMessage.class, this::createAccount)
                .onMessage(BankMessage.DepositMessage.class, this::deposit)
                .onMessage(BankMessage.WithDrawalMessage.class, this::withdraw)
                .onMessage(BankMessage.BalanceMessage.class, this::getBalance)
                .build();
    }

    private Behavior<BankMessage> createAccount(BankMessage.CreateAccountMessage message) {
        // Create an account and an account manager actor for it
        String accountNumber = UUID.randomUUID().toString();
        Account account = new Account(accountNumber, message.amount);
        ActorRef<BankMessage> actor = getContext().spawn(AccountManagerActor.create(account), accountNumber);
        accounts.put(accountNumber, actor);
        // Let the customer know that the account has been created
        message.replyTo.tell(new BankMessage.GeneralReplyMessage(true, "Account " + accountNumber + " has been created"));
        return Behaviors.same();
    }

    private Behavior<BankMessage> deposit(BankMessage.DepositMessage message) {
        // Look up the account manager actor
        ActorRef<BankMessage> actor = accounts.get(message.accountNumber);
        if (actor == null) {
            message.replyTo.tell(new BankMessage.GeneralReplyMessage(false, "Account does not exist"));
        } else {
            // Forward to appropriate actor
            actor.tell(message);
        }
        return Behaviors.same();
    }

    private Behavior<BankMessage> withdraw(BankMessage.WithDrawalMessage message) {
        // Look up the account manager actor
        ActorRef<BankMessage> actor = accounts.get(message.accountNumber);
        if (actor == null) {
            message.replyTo.tell(new BankMessage.GeneralReplyMessage(false, "Account does not exist"));
        } else {
            // Forward to appropriate actor
            actor.tell(message);
        }
        return Behaviors.same();
    }

    private Behavior<BankMessage> getBalance(BankMessage.BalanceMessage message) {
        // Look up the account manager actor
        ActorRef<BankMessage> actor = accounts.get(message.accountNumber);
        if (actor == null) {
            message.replyTo.tell(new BankMessage.GeneralReplyMessage(false, "Account does not exist"));
        } else {
            // Forward to appropriate actor
            actor.tell(message);
        }
        return Behaviors.same();
    }

}
