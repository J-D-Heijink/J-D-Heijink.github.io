package nl.saxion.concurrency.bank;

import akka.actor.typed.ActorSystem;
import akka.actor.typed.javadsl.AskPattern;
import nl.saxion.concurrency.bank.actors.BankActor;
import nl.saxion.concurrency.bank.messages.BankMessage;

import java.time.Duration;
import java.util.Scanner;
import java.util.concurrent.CompletionStage;

public class StartAkka {

    private ActorSystem<BankMessage> system;
    public static void main(String[] args) {
        new StartAkka().run(args);

    }

    private void run(String[] args) {
        system = ActorSystem.create(BankActor.create(),"MyAkkaSystem");
        System.out.println("Send a command to the actor, q to quit the system");
        commandLoop();
        system.terminate();
        system.getWhenTerminated().whenComplete((done,err) -> {
            System.out.println("Akka has shut down!");
        });
    }

    private void commandLoop() {
        String help = "Commands:\n" +
                "\n" +
                "c: Create account\n" +
                "d: Deposit\n" +
                "t: Take\n" +
                "s: Show balance\n" +
                "?: This menu\n" +
                "Q: Quit\n";
        System.out.println(help);
        Scanner s = new Scanner(System.in);
        String c = s.nextLine().toLowerCase();
        while (!c.equals("q")) {
            switch (c) {
                case "?":
                    System.out.println(help);
                    break;
                case "c":
                    createAccount();
                    break;
                case "d":
                    deposit();
                    break;
                case "t":
                    take();
                    break;
                case "s":
                    showBalance();
                    break;
            }
            c = s.nextLine().toLowerCase();
        }
    }

    private void processReply(CompletionStage<BankMessage> result) {
        // Wait for the result
        BankMessage message = result.toCompletableFuture().join();
        if (message instanceof BankMessage.GeneralReplyMessage) {
            System.out.println("Status:  " + ((BankMessage.GeneralReplyMessage) message).status);
            System.out.println("Message: " + ((BankMessage.GeneralReplyMessage) message).message);
        } else {
            System.err.println("Received an unknown message");
        }
    }

    public void createAccount() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the amount to start with: ");
        long amount = s.nextLong();
        CompletionStage<BankMessage> result = AskPattern.ask(
                system,
                replyTo -> new BankMessage.CreateAccountMessage(amount, replyTo),
                Duration.ofSeconds(6),
                system.scheduler()
        );
        // Wait for the result
        processReply(result);
    }

    public void deposit() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the account number: ");
        String accountNumber = s.nextLine();
        System.out.println("Enter the amount to deposit: ");
        long amount = s.nextLong();
        CompletionStage<BankMessage> result = AskPattern.ask(
                system,
                replyTo -> new BankMessage.DepositMessage(amount, accountNumber, replyTo),
                Duration.ofSeconds(6),
                system.scheduler()
        );
        processReply(result);
    }

    public void take() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the account number: ");
        String accountNumber = s.nextLine();
        System.out.println("Enter the amount to withdraw: ");
        long amount = s.nextLong();
        CompletionStage<BankMessage> result = AskPattern.ask(
                system,
                replyTo -> new BankMessage.WithDrawalMessage(amount, accountNumber, replyTo),
                Duration.ofSeconds(6),
                system.scheduler()
        );
        // Wait for the result
        processReply(result);
    }

    public void showBalance() {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter the account number: ");
        String accountNumber = s.nextLine();
        CompletionStage<BankMessage> result = AskPattern.ask(
                system,
                replyTo -> new BankMessage.BalanceMessage(accountNumber, replyTo),
                Duration.ofSeconds(6),
                system.scheduler()
        );
        // Wait for the result
        processReply(result);
    }
}
