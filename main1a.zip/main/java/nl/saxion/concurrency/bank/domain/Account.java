package nl.saxion.concurrency.bank.domain;

public class Account {

    public final String accountNumber;
    private long balance = 0;

    public Account(String accountNumber, long balance) {
        this.accountNumber = accountNumber;
        this.balance = balance;
    }

    public long getBalance() {
        return balance;
    }

    public long take(long amount) throws BalanceException {
        if (amount > balance)  throw new BalanceException("Insufficient funds");
        balance = balance - amount;
        return balance;
    }

    public long deposit(long amount)  {
        balance = balance + amount;
        return  balance;
    }

}
