package nl.saxion.concurrency.bank.domain;

public class BalanceException extends Exception {
    public BalanceException(String message) {
        super(message);
    }

}
