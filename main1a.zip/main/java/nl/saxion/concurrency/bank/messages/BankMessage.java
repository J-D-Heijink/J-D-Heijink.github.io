package nl.saxion.concurrency.bank.messages;


import akka.actor.typed.ActorRef;

/*
We will derive all our messages from the interface BankMessages
 */
public interface BankMessage {

    class GeneralReplyMessage implements BankMessage {
        public final boolean status;
        public final String message;

        public GeneralReplyMessage(boolean status, String message) {
            this.status = status;
            this.message = message;
        }
    }

    class CreateAccountMessage implements BankMessage {
        public final long amount;
        public final ActorRef<BankMessage> replyTo;

        public CreateAccountMessage(long amount, ActorRef<BankMessage> replyTo) {
            this.amount = amount;
            this.replyTo = replyTo;
        }
    }

    class WithDrawalMessage implements BankMessage {
        public final long amount;
        public final String accountNumber;
        public final ActorRef<BankMessage> replyTo;

        public WithDrawalMessage(long amount, String accountNumber, ActorRef<BankMessage> replyTo) {
            this.amount = amount;
            this.accountNumber = accountNumber;
            this.replyTo = replyTo;
        }
    }

    class DepositMessage implements BankMessage {
        public final long amount;
        public final String accountNumber;
        public final ActorRef<BankMessage> replyTo;

        public DepositMessage(long amount, String accountNumber, ActorRef<BankMessage> replyTo) {
            this.amount = amount;
            this.accountNumber = accountNumber;
            this.replyTo = replyTo;
        }
    }

    class BalanceMessage implements BankMessage {
        public final String accountNumber;
        public final ActorRef<BankMessage> replyTo;

        public BalanceMessage(String accountNumber, ActorRef<BankMessage> replyTo) {
            this.accountNumber = accountNumber;
            this.replyTo = replyTo;
        }
    }

}
